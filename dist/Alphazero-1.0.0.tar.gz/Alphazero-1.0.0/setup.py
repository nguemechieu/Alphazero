from setuptools import setup, find_packages

setup(
    name="Alphazero",
    version="1.0.0",
    author="Noel M nguemechieu",
    author_email="nguemechieu@live.com",
    description="AI-powered trading software for MetaTrader 4/5",
    long_description_content_type="text/x-rst",
    keywords=['run', 'open', 'trade'],
    url="https://github.com/nguemechieu/alphazero",
    include_package_data=True,
    zip_safe=False,
    packages=find_packages(),
    license='MIT',  # Corrected the license classifier
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",  # Adjusted the license classifier
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.12',  # Adjusted the minimum Python version
    entry_points={
        'console_scripts': [
            'Alphazero = alphazero.main:main',
        ],
    },
    install_requires=['requirements.txt' ],
        
        # Add other dependencies as needed
    extras_require={
        'dev': [
            'pytest',
            'pytest-cov',
        ],
    },
)
